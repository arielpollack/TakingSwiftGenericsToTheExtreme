// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public protocol Identifiable {
    static var uniqueIdentifier: String { get }
}

extension UIView: Identifiable {
    public static var uniqueIdentifier: String {
        return String(reflecting: self)
    }
}
