// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public class StatusCell: UITableViewCell, Configurable {
    
    let statusColorView = UIView()
    let lblTitle = UILabel()
    
    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(statusColorView)
        statusColorView.layer.cornerRadius = 3
        
        contentView.addSubview(lblTitle)
        lblTitle.textAlignment = .center
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        let frame = bounds.inset(by: UIEdgeInsets(top: 4, left: 4, bottom: 4, right: 4))
        statusColorView.frame = frame
        lblTitle.frame = frame
    }

    public func configure(with status: Status) {
        lblTitle.text = status.title
        lblTitle.textColor = status.textColor
        statusColorView.backgroundColor = status.backgroundColor
    }
}
