// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public class MenuView<OptionCell>: ConfigurableView,
UITableViewDataSource, UITableViewDelegate 
where OptionCell: ConfigurableCell {
    
    public typealias OptionType = OptionCell.Data
    public typealias SelectOptionClosure = (OptionType) -> Void
    
    // vars
    private var didSelectOption: SelectOptionClosure
    private var options: [OptionType] {
        didSet { tableView.reloadData() }
    }
    
    // views
    private lazy var tableView: UITableView = {
        let tableView = UITableView(frame: .zero)
        tableView.register(OptionCell.self, forCellReuseIdentifier: OptionCell.uniqueIdentifier)
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 44
        tableView.separatorStyle = .none
        return tableView
    }()
    
    public init(didSelectOption: @escaping SelectOptionClosure, options: [OptionType] = []) {
        self.didSelectOption = didSelectOption
        self.options = options
        super.init(frame: .zero)
        
        addSubview(tableView)
        
        layer.shadowOpacity = 0.2
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = .zero
        layer.shadowRadius = 5
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        tableView.frame = bounds
    }
    
    public func configure(with options: [OptionType]) {
        self.options = options
    }
    
    // MARK: UITableViewDataSource
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return options.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: OptionCell.uniqueIdentifier, for: indexPath) as! OptionCell
        
        let option = options[indexPath.row]
        cell.configure(with: option)
        
        return cell
    }
    
    // MARK: UITableViewDelegate
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let option = options[indexPath.row]
        didSelectOption(option)
    }
}
