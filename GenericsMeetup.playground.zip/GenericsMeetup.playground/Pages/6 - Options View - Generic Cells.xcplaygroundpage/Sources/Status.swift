// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public struct Status {
    public let title: String
    public let textColor: UIColor
    public let backgroundColor: UIColor
}

public let MockStatuses = [
    Status(title: "Working on it", textColor: .white, backgroundColor: .workingOrange),
    Status(title: "Done", textColor: .white, backgroundColor: .doneGreen),
    Status(title: "Stuck", textColor: .white, backgroundColor: .stuckRed)
]
