// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

extension UIColor {
    convenience init(r: UInt32, g: UInt32, b: UInt32) {
        if #available(iOS 10.0, *) {
            self.init(displayP3Red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: 1)
        } else {
            self.init(red: CGFloat(r) / 255, green: CGFloat(g) / 255, blue: CGFloat(b) / 255, alpha: 1)
        }
    }
}

extension UIColor {
    public static var stuckRed = UIColor(r: 228, g: 66, b: 88)
    public static var workingOrange = UIColor(r: 255, g: 172, b: 44)
    public static var doneGreen = UIColor(r: 0, g: 202, b: 114)
}
