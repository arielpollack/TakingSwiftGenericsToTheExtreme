// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white

        typealias StatusMenu = MenuView<StatusCell>
        let menuView = StatusMenu(didSelectOption: { status in
            print(status.title)
        })
        menuView.frame = CGRect(x: 100, y: 200, width: 120, height: 132)
        menuView.configure(with: MockStatuses)
        
        view.addSubview(menuView)
        self.view = view
    }
}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
