// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit
import PlaygroundSupport

enum BoardMenuOption {
    case delete
    case rename
}

extension BoardMenuOption: MenuOption {
    var title: String {
        switch self {
        case .rename: return "Rename"
        case .delete: return "Delete"
        }
    }
    
    var icon: UIImage {
        switch self {
        case .rename: return UIImage(named: "rename")!
        case .delete: return UIImage(named: "trash")!
        }
    }
}

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        typealias BoardMenu = MenuView<BoardMenuOption>
        let menuView = BoardMenu(didSelectOption: { option in
            print(option)
        })
        menuView.frame = CGRect(x: 100, y: 200, width: 120, height: 88)
        menuView.configure(with: [.rename, .delete])
        
        view.addSubview(menuView)
        self.view = view
    }
}

// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
