// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public class MenuOptionCell: UITableViewCell, Configurable {
    
    let lblTitle = UILabel()
    let imgIcon = UIImageView()
    
    override public init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.addSubview(lblTitle)
        contentView.addSubview(imgIcon)
        imgIcon.contentMode = .center
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError()
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        imgIcon.frame = CGRect(x: 0, y: 0, width: 50, height: bounds.height)
        lblTitle.frame = CGRect(x: 50, y: 0, width: bounds.width - 30, height: bounds.height)
    }
    
    public func configure(with option: MenuOption) {
        imgIcon.image = option.icon
        lblTitle.text = option.title
    }
}
