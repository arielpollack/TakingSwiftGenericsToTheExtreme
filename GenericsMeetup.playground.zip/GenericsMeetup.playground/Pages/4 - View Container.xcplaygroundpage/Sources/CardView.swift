// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit

public class CardView<View>: ConfigurableView
where View: ConfigurableView {
    
    public typealias Data = (title: String, data: View.Data)
    
    let containedView = View(frame: .zero)
    let lblTitle = UILabel(frame: .zero)
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    // called in init
    func setupViews() {
        backgroundColor = .white
        addSubview(lblTitle)
        addSubview(containedView)
        
        layer.shadowOpacity = 0.2
        layer.shadowColor = UIColor.black.cgColor
        layer.shadowOffset = .zero
        layer.shadowRadius = 5
    }
    
    override public func layoutSubviews() {
        super.layoutSubviews()
        layer.cornerRadius = 10
        lblTitle.frame = CGRect(x: 10, y: 10, width: 100, height: 20)
        containedView.frame = bounds.inset(by: UIEdgeInsets(top: 40, left: 10, bottom: 10, right: 10))
    }
    
    public func configure(with data: Data) {
        lblTitle.text = data.title
        containedView.configure(with: data.data)
    }
}
