// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import UIKit
import PlaygroundSupport

extension UILabel: Configurable {
    public func configure(with data: String) {
        self.text = data
    }
}

extension UIImageView: Configurable {
    public func configure(with data: UIImage) {
        self.image = data
    }
}

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .white
        
        let labelCard = CardView<UILabel>()
        labelCard.frame = CGRect(x: 100, y: 100, width: 200, height: 200)
        labelCard.configure(with: (title: "Text", "Hello world!"))
        
        let imageCard = CardView<UIImageView>()
        imageCard.frame = CGRect(x: 100, y: 320, width: 200, height: 200)
        imageCard.configure(with: (
            title: "Image",
            data: UIImage(named: "swift")!
        ))
        // setup frame
        
        view.addSubview(labelCard)
        view.addSubview(imageCard)
        self.view = view
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
