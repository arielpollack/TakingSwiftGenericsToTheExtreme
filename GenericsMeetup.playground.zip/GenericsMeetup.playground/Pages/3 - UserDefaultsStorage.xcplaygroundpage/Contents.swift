// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import Foundation

class UserDefaultsStorage<T>: Storage
where T: NSCoding {
    private let key: String
    private let userDefaults: UserDefaults
    init(key: String, userDefaults: UserDefaults = .standard) {
        self.key = key
        self.userDefaults = userDefaults
    }
    
    func getValues() -> [T] {
        guard let array = userDefaults.value(forKey: key) as? [T]
            else { return [] }
        return array
    }
    
    func set(values: [T]) {
        userDefaults.setValue(values, forKey: key)
    }
    
    func clear() {
        userDefaults.removeObject(forKey: key)
    }
}

typealias NumbersStorage = UserDefaultsStorage<NSNumber>

let visitedBoards = NumbersStorage(key: "visited_boards_ids")

let boardIds = [1, 2, 3].map(NSNumber.init)
visitedBoards.set(values: boardIds)
visitedBoards.getValues() // => [1, 2, 3]
