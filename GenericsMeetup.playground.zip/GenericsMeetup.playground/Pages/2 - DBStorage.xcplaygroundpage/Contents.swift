// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import Foundation

protocol DBSavable {}

struct User: DBSavable {}

// Storing values to a local db
class DBStorage<T>: Storage where T: DBSavable {
    func getValues() -> [T] { return [] }
    func set(values: [T]) {}
}

final class UsersDBStorage: DBStorage<User> {
    func someUsersSpecificMethod() {
        let values = getValues() // values: [User]
    }
}
