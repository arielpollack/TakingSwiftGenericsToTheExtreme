// All rights reserved to Ariel Pollack and monday.com.
// This code was presented as part of "Taking Generics To The Extreme" session
// in "iOS TLV Meetup" on 14/07/2019

import Foundation

struct SimpleStorage<T>: Storage {
    private var storedValues: [T] = []
    
    public func getValues() -> [T] {
        return storedValues
    }
    
    public mutating func set(values: [T]) {
        self.storedValues = values
    }
}

// Usage
var storage = SimpleStorage<Int>()
storage.set(values: [1, 2, 3])
storage.getValues()

// Extending all `Storage` implementations to add functionality
extension Storage where T: AdditiveArithmetic {
    func sum() -> T {
        return getValues().reduce(.zero, +)
    }
}

storage.sum() // => 6
